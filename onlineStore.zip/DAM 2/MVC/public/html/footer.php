
	</br>
	</br>
	</br>
<nav class="navbar navbar-default navbar-fixed-bottom navbar-inverse" role="navigation">
 



	<p class="navbar-text">Rodrigo Adelino Candido</p>


 
</nav>
	</footer>




</body>	

