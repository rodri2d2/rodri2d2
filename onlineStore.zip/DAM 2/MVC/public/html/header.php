<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">


	<!-- BootStrap -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

	
	<!--JQuery-->
	<script type="text/javascript" src="/dam/MVC/public/js/jquery.js"></script>

	<!--DEV styles and Scripts-->
	<link rel="stylesheet" type="text/css" href="../public/css/style.css">
	<script type="text/javascript" src="/dam/MVC/public/js/script.js"></script>

</head>
<body>

	<header>
		
	<div class="navbar navbar-default">
		
		
		<!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="/dam/MVC/public/home">Home</a></li>
        <li><a href="/dam/MVC/public/product">Productos</a></li>
        <li><a href="/dam/MVC/public/about">Sobre</a></li>
        <li><a href="/dam/MVC/public/contact">Contactenos</a></li>
        </ul>
        	<form class="navbar-form navbar-left" role="search">
		        <div class="form-group">
		          <input type="text" class="form-control" placeholder="Search">
		        </div>
        		<button type="submit" class="btn btn-default">Buscar</button>
      		</form>
      
      <ul class="nav navbar-nav navbar-right">
      	<li>
	       <p  class="btn btn-default navbar-text" >
	         <a href="/dam/MVC/public/product/cart" class="navbar-link">
	         	<span class="glyphicon glyphicon-shopping-cart " aria-hidden="true">
	         		<span id="cart"></span>
	         	</span>
	         </a>
			</p>
       </li>
     
      	
      </ul>



       
      </ul>
     
     
      </ul>
    </div><!-- /.navbar-collapse -->

	</div>




