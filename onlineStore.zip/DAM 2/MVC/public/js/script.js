


$(document).ready(init);


function init(){
	$(".btnAdd").click(addToCart);
	$("#cart").load("/dam/MVC/app/helper/cart.php");
	$(".btnRemove").click(removeFromCart);
	$(".btnRemoveAll").click(removeAllFromCart);
	


}


function addToCart(){

	var x =  $(this).attr("value");
	$("#cart").load("/dam/MVC/app/helper/cart.php?p="+x);

}

function removeFromCart(){

	var x =  $(this).attr("value");
	$("#cart").load("/dam/MVC/app/helper/cart.php?remove="+x);
	  location.reload();

}

function removeAllFromCart(){
	$("#cart").load("/dam/MVC/app/helper/cart.php?removeAll=removeAllFromCart");
	  location.reload();

}

