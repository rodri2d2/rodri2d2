<?php


/*Simplesmente hace un require al init.php que se encuentra en 
* app/init.php
* Este archivo se encarga de hacer un autoload del controlador 
* principal que se encarga de las demas llamadas
*/

	require_once ('../app/init.php');
	$app = new App;





?>