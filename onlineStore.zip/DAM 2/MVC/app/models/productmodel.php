<?php



	class ProductModel{

		
		
	

		public function __construct(){

			require_once('../app/core/dbhelper.php');

		}


		/*
			Se encarga de generar un html con todos los productos para seren expostos en la 
		    HOME de la pagina
		*/

		public function listAllProducts(){
			
			//
			$db = new DataBaseHelper();	

			//El HTML que sera generado
			$html = "";

			//Se crea una query para ser llamada
			$query = "SELECT * FROM products WHERE stock >0";
			$result= $db->get($query);
			while ($row = mysqli_fetch_array($result)){

				$imageQuery = "SELECT image FROM productimage WHERE idProduct=".$row[0];
				$imageResult = $db->get($imageQuery);
				$imageRow = mysqli_fetch_array($imageResult);

						//Crea un html con todos los datos necesarios, incluyendo los estilos
						$html.= '<div class="col-md-3">
								 	<div class="thumbnail thumbDiv">
										<div class="caption text-center">
											 <h3>'.$row[1].'</h3>
										</div>
										<img class="img-responsive homeThumbImgSize"src="../public/images/'.$imageRow['image'].'">
										<h4 class="text-center">'.$row[2].'</h4>
										<p><h4 class="text-center">'.$row['price'].'€</h4></p>
										<p class="text-center">
											<a href="product/productDetail/'.$row[0].'" class="btn btn-default" >+ Info</a>
											<a class="btn btn-danger btnAdd" value="'.$row[0].'">Add to cart</a>
										</p>
									</div>
								</div>';											
			}

			return $html;

		}



		/*Devuelve solo un producto para ser mostados como detalle del producto
		* se le pasa el ID del producto que queremos mas informaciones
		*/
		public function productDetail($idProduct){
			//
			$db = new DataBaseHelper();	
				
			//El HTML que sera generado y devuelto
			$html = "";


			//Se crea una query para ser llamada
			$query ="SELECT * FROM products WHERE idProduct=".$idProduct;
			$result = $db->get($query);
			while($row = mysqli_fetch_array($result)){

			
				$imageQuery = "SELECT image FROM productimage WHERE idProduct=".$row[0];
				$imageResult = $db->get($imageQuery);
				$imageRow = mysqli_fetch_array($imageResult);


				
				//Crea un html con todos los datos necesarios, incluyendo los estilos
						$html.= ' <div class="col-md-4">
									 	<div class="jumbotron">
										<img class="img-responsive imageDetail"src="/dam/MVC/public/images/'.$imageRow['image'].'">
									</div>
								  </div>
								  
								  <div class="col-md-4">
	
								  	<div class="jumbotron jumbDiv">
										 <h2>'.$row[1].'</h2>
										 <p></p>
										 <p> <h4>'.$row[3].'</h4></>
									</div>
								 
								  </div>


								   <div class="col-md-4">
									 <div class="jumbotron">

										 <h1 class="text-center">'.$row['price'].'€</h1>
										 <p class="text-center">
										 	<a class="btn btn-danger btnAdd" value="'.$row[0].'">Add to cart</a>
										 </p>
									</div>
								  </div>
								';	
							}
			return $html;
		}


		public function cart(){

		/*
		 * Esto es un pequeño juego con el scope de las variables en PHP
		 * la idea es enviar un GET pero un require llama a un archivo que esta
		 * dentro
		 * El archivo tendria que se llamar cart.php?show=1 
		 * 
		 * Eso es spaguetti!!!!! Pero no he encontrado otra forma de hacerlo
		 *
		*/
		$_GET['show'] = 1;
		$cart = require_once('../app/helper/cart.php');
		return	$cart;

		}

}

?>