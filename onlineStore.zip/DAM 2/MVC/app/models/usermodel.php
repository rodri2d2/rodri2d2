<?php 


	class UserModel{


		public function getUser($name, $pass){

			//
			$db = new DataBaseHelper();	

		   $query = "SELECT idCustomer FROM customers WHERE name ='".$name."' AND password=".$pass;
		   $result = $db->get($query);
		   $row = mysqli_fetch_array($result);
		   if(!empty($row)){
		   	return $row[0];
		   }
		   
		}


		/*
			En setPurchage se aprovecha otra vez de los scopes de las variables en PHP
			De forma que si hay pedido, se recupera esos valores.
			1. Se hace la insercion del pedido
			2. Se recupera el pedido
			3. Se utiliza la variable de secion para recuperar los items
			4. Se inserta en lineas de pedido
			5. Se actualiza las existencias del producto en la base de datos
		*/
		public function setPuchages($idCustomer){

			//
			$html="";

			//
			$db = new DataBaseHelper();

			if($_SESSION['counter']>0){

				//
				$query  ="INSERT INTO orders VALUES(NULL,".$idCustomer.", '".date('Y-m-d')."', 0)";
				$result = $db->get($query);

				//
				$query  = "SELECT idOrder FROM orders WHERE idCustomer=".$idCustomer." ORDER BY orderDate DESC LIMIT 1";
				$result = $db->get($query);
				$row = mysqli_fetch_array($result);
				$idOrder = $row[0];

				//
				for($i =0; $i<$_SESSION['counter']; $i++){
					//El el ultimo campo de la insert seria la cantidad, de momento se añade como uno, dado que 
					// en el cart aun no se hace el control de cantidades por prducto
					$query = "INSERT INTO orderdetails VALUES(NULL,".$idOrder.",".$_SESSION['product'][$i].",'1')";
					$result = $db->get($query);


					$queryStock  = "SELECT stock FROM products WHERE idProduct=".$_SESSION['product'][$i];
					$resultStock = $db->get($queryStock);
					while ($rowStock = mysqli_fetch_array($resultStock)) {
						$stock = $rowStock[0];
						$updateStock = "UPDATE products SET stock='".($stock-1)."' WHERE idProduct=".$_SESSION['product'][$i];
						$stockresult = $db->get($updateStock);
					}


				}
				if($result == 1){

					$html.='

							<div class="jumbotron"></br>
  								<h1>Pedido reslizado correctamente!</h1>
  									<p>Muchas gracias por confiar en TIENDA ONLINE, en pocos dias disfrutaras de
  									de su producto...!</p>
  									
  									</br>
  									</br>
  									<h5></h5>
  							
							</div>';
							session_destroy();
							return $html;
				}

			}
		}


		public function setUser($name, $surname_1, $surname_2, $dni, $email, $pass, $phone, $adress, $zipcode, $city, $country){

			//
			$db = new DataBaseHelper();

			//
			$html="";	

			$query="INSERT INTO customers VALUES (NULL, '".$name."', '".$surname_1."', '".$surname_2."', 
					'".$dni."', '".$email."', '".$pass."', '".$phone."', '".$adress."', '".$zipcode."', '".$city."', '".$country."')";


			$result = $db->get($query);
			if(!is_null($result)){

				$html.='<div class="jumbotron"></br>
  								<h1>Bien venido,'.$name.'</h1>
  									<p>Muchas gracias por confiar en TIENDA ONLINE, clique otra vez en 
  									le carro de compra para finlizarla!!!</p>
  									
  									</br>
  									</br>
  									<h5></h5>

  									<div class="col-md-4">
							  <a href="/dam/MVC/public/login" class="btn btn-info">
								 	 Confirmar compra
								 </a>
						  </div>
						</div>';
			}
			return $html;

		}

	}

?>


