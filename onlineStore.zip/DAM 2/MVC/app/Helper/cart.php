<?php

	/*
	*Esto es un helper para auydar a manejar el carro de compra
	* ya que en el caso necesitaba una interaccion con javascript
	* Aqui se crea una variable de seccion 
	* Si el usuario hace un click en add cart, se añade al value del boton
	* Si se hace un click en el carro para ver los prodctos, se genera una HTML que
	* es devuelto al objeto producto que se encarga de llamar el controlado producto
	* que entrega el HTML generado a una vista
	*/


	//El HTML que sera generado
			$html = "";

	//Para sumar los valores
			$suma = 0;

	//
			$query ="";


	 	if(!isset($_SESSION)) { 

	        session_start(); 
	        if(!isset($_SESSION['counter'])){
			$_SESSION['counter'] = 0;
			}
	    }


		if(isset($_GET['p'])){
					$_SESSION['product'][$_SESSION['counter']] = $_GET['p'];
				    $_SESSION['counter']++;

		}

		if(isset($_GET['remove'])){
					unset($_SESSION['product'][$_SESSION['counter']]);
				    $_SESSION['counter']--;
				    header("location");

		}
		
		if(!isset($_GET['show'])){

			echo $_SESSION['counter'];
		}

		if(isset($_GET['removeAll'])){
			session_start();
			session_destroy();
		}


		

		/*
		 *A partir de aqui es necesario una conexion a la db
		 * Por ese motivo la clase database deja de ser abstracta 
		 * y se hace una clase normal se forma que se puede ser instanciada 
		 * tanto dentro del paquete MVC como fuera 
		 * con los datos recuperado de la db se genera un HTML que sera devuelto
		*/
		

		//require_once('../app/core/dbhelper.php');
		/*
	     * Por algun motivo al intentar hacer el require del alchivo anterior no me funciona
	     * Asi que hay otra clase dentro de helper que hacer lo mismo para el carro
		*/
		require_once('dbhelper.php');
		$db = new DataBaseHelperCart();	

			for($i=0; $i<$_SESSION['counter']; $i++){

				$query = "SELECT * FROM products WHERE idProduct=".$_SESSION['product'][$i];					
				$result= $db->get($query);				
				while ($row = mysqli_fetch_array($result)){

					$html.='<div class="row">
							<table class="table table-hover">
					        <tr>
							  <td>
							    <div class="btn col-md-4" >
								 <a class="btn btn-danger btnRemove" value="'.$row[0].'">
								 	 <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
								 </a>
								   	
								  </a>
								</div>
							  </td>
							  <td>
								<div class="col-md-4">
								  <h3>'.$row[1].'</h3></li>
								 </div>
							  </td>
							  <td>
								 <div class="col-md-4">
								  <h3>'.$row['price'].'</h3></li>
								 </div>
							  </td>
						
							';
							$suma = $suma + $row['price'];
				}

			}

			if($suma==0){
				return $html.='<div class="row bg-danger">	
									  <div class="col-md-4">
										 <p class="text-center"><h3>No hay productos seleccionados</h3></p>
									  </div>
								</div>';
			}

			$html.='</tr>
					<tr></tr>
					<tr class="danger">
						<td></td>
						<td class="warning">
						  <div class="col-md-4">
							 <h3>Subtotal</h3></li>
						  </div>
						</td>
						<td class="danger">
						  <div class="col-md-4">
							 <h3>'.$suma.'€</h3></li>
						  </div>
						</td>

					</tr>
					</table>
					
						  <div class="col-md-4">
							  <a href="/dam/MVC/public/login" class="btn btn-info">
								 	 Confirmar compra
								 </a>
						  </div>
					
						  <div class="col-md-4">
							  <a class="btn btn-warning btnRemoveAll" >
								 	 Vaciar carrito
								 </a>
						  </div>
					
				
					</div>

					';

	    return $html;
		
	
		

?>