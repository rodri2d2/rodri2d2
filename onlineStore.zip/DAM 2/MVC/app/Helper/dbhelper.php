<?php 


		class DataBaseHelperCart {




		public function setConnetion(){

			return  mysqli_connect("localhost","root","","tiendaonline");


		}


		public  function get($query){
			$connection = $this->setConnetion();
			//



			//Genera una "ARRAY DE LA CONEXION", que contiene los datos a seren trabajados
			$result = mysqli_query($connection, $query);
			



			//
			mysqli_close($connection);
			return $result;

		}
		

		
		


	}

?>