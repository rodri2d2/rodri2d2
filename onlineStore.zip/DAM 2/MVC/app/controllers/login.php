<?php 


	class Login extends Controller{


		public function index(){

			$this->view('login/index');

		}

		/*Para que el programa siga funcionando con modelo MVC en esta parte se hace uso 
		  del los de las variables pasadas por POST
		  Asi que lo primero que se hace es recuperarlas y depues enviarlas al getUser del modelo
		*/
		public function getUser(){


			$html  = "";
			$name  = $_POST['name'];
			$pass  = $_POST['pass'];
			
			$loginController = $this->model('UserModel');
			//Debido a un pequeño problema que no he encontrado solucion, el programa no recibe el email, asi que se cambia por el nombre
			$result = $loginController->getUser($name, $pass);
			if(!empty($result)){
			

				$html = $loginController->setPuchages($result);
				
				//INFORMACIN ENVIADA A LA VISTA
				$this->view('product/orderlist', $html);
				

			}else{

				$this->view('login/userincorrect', $html);
			}
			
		

		}

		public function setUserView(){

			$this->view('login/userregister');

		}

		public function setUser(){

			

			//
			$name        = $_POST['name'];
			$surname_1   = $_POST['surname_1'];
			$surname_2   = $_POST['surname_2'];
			$dni         = $_POST['dni'];
			$email       = $_POST['email'];
			$pass        = $_POST['pass'];
			$phone       = $_POST['phone'];
			$adress      = $_POST['adress'];
			$zipcode     = $_POST['zipcode'];
			$city	     = $_POST['city'];
			$country     = $_POST['country'];


			$usermodel = $this->model('UserModel');
			$html = $usermodel->setUser($name, $surname_1, $surname_2, $dni, $email, $pass, $phone, $adress, $zipcode, $city, $country);
			if(!empty($html)){
				
				$this->view('login/userregistration', $html);
			}



		}



	}



?>