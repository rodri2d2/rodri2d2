<?php 


	class Home extends Controller{

		

		public function __construct(){

			$this->index();

		}

		public function index(){

			/**
			*Cuando estamos en el index, simplemente se rellena la pagina con el 
			*listado de productos utilizando el metodo getAllProduct de modelo producto
			*/
			$productmodel = $this->model('ProductModel');
			$html=$productmodel->listAllProducts();

			//INFORMACION ENVIADA A LA VISTA
			$this->view('home/index', $html);
					
			}


		public function detail($idProducto){

			$productController = $this->model('ProductModel');
			$productController->productDetail($idProducto);

		}


		public function cart(){

			$html = "";

			//
			$productmodel = $this->model('ProductModel');			
			$html = $productmodel->cart();

			//INFORMACION ENVIADA A LA VISTA
			$this->view('home/index', $html);

		}


		
	}



?>