<?php 


	class Product extends Controller {

		

		public function __construct(){


		}

		public function index(){

			//INFORMACION ENVIADA A LA VISTA
			$this->view('product/index');


		}

		public function productDetail($idProduct){

			//
			$productmodel = $this->model('ProductModel');

			//
			$html = $productmodel->productDetail($idProduct);

			
			//INFORMACION ENVIADA A LA VISTA
			$this->view('product/productdetail', $html);
		}


		public function cart(){
			//
			$productmodel = $this->model('ProductModel');			
			$html = $productmodel->cart();

			//INFORMACION ENVIADA A LA VISTA
			$this->view('product/productcart', $html);




			
			
		}


		
	}



?>