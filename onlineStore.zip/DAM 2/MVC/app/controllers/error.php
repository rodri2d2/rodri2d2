<?php 


	class Error extends Controller{

		

		public function __construct(){

			$this->index();

		}


		public function index(){

			$this->view('error/error');

		}

	}
?>