<?php



	class Contact extends Controller{


		public function __construct(){

			$this->index();

		}


		public function index(){

			$this->view('contact/index');

		}

	}
		



?>