<?php

/*Lo primero que hace esta clase es un routing para haya simpre un
  controlador por defecto con un metodo por defecto, asi como sus parametros
*/
	class App{

		//Default Controlador/metodo/parametro
		protected $controller = 'home';
		protected $method     = 'index';
		protected $param      = [];

		public function __construct(){

			session_start();
			if (!isset($_SESSION['counter'])) {
				$_SESSION['counter'] = 0;
			}

			//DEBUG
			//print_r($this->parseUrl());
			$url = $this->parseUrl();


			/*
			 Si exite al menos un controlador o sea url[0]
			 La APP busca si exite el archivo para el controlador
			 Caso no encuentre sera Pagina no entrada
			 Caso encuentre se crea una instancia del controlador
			*/
			if(isset($url[0])){
				if(file_exists('../app/controllers/'.$url[0].'.php')){
					
					$this->controller = $url[0];
					unset($url[0]);

				}else{

					//Instancia del controlador caso no exista
					require_once('../app/controllers/error.php');
					return $erro = new Error();
				}

			}else{

				//Llamada por defecto
				require_once ('../app/controllers/'.$this->controller.'.php');
				$this->controller = new $this->controller;

			}

			//Instancia del controlador en caso positivo
			require_once ('../app/controllers/'. $this->controller.'.php');
			$this->controller = new $this->controller;
			
			/*
			  Lo mismo que el codigo anterior
			  Si exite el metodo pues se le asigna al method
			  Caso contratrio todos los controladores contienen
			  un metodo de index por defecto
			*/
			if(isset($url[1])){
				if(method_exists($this->controller, $url[1])){
					$this->method = $url[1];
					unset($url[1]);
				}
			}

			//Boilerplate code desde la pagina oficial de PHP
			//Equivalente a un IF ELSE 
			$this->param = $url ? array_values($url) : [];

			//LLamada completa al CONTROLADOR/METODO/PARAMETRO
            call_user_func_array([$this->controller, $this->method], $this->param);
        }


		/*
			Esta funcion se ocupa de recorrer la URL y retornarla
			y dividirla para que la app puede identificar
			el es seguinte esquema:

			Controlador/Metodo/Parametro
		*/
		public function parseUrl(){

			if(isset($_GET['url'])){
				return $url = explode('/', filter_var(rtrim($_GET['url'], '/'), FILTER_SANITIZE_URL));

			}


		}

}//END OF CLASS



?>