<?php

/*
	Esta clase es el controlador principal
	Es por esta clase que se puede localizar los modelos y las vista que
	seran llamadas durante la execucion del condigo

*/

	class Controller{


		/*
			Esta funcion es llamada por alguna clase controladora
			La clase controlador PIDE UN MODELO. El controlador pricipal
			lo encuenra y devuelve una instancia de este modelo 

		*/
		public function model($model){

			require_once('../app/models/'.$model.'.php');
			return new $model;

		}

		/*
		  Esta funcion es llamada por alguna clase controladora
		  Carga na vista segun los parametros pasados, donde normalmente
		  el parametro de $hmtl=[] sera una HTML completo con todo los estilos
		  formateo y datos que deben contener la vista

		*/
		public function view($view, $html=[]){

			require_once('../public/html/header.php');
			require_once ('../app/views/'.$view.'.php');
			require_once('../public/html/footer.php');

		}

	}

?>