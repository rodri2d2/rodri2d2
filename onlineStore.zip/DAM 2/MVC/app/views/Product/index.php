<div class="container">
	

		</br></br></br></br>
		<div class="jumbotron">
		  <h1>Tienda Online</h1>
		  <p> Los productos presentados, asi como las informaciones de los mismo, tienen fines educativos
		  y no deben ser utilizados de forma comercial</p>
		  
		</div>

</div>