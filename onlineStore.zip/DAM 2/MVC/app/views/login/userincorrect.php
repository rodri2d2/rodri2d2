</br>
</br>
</br>

<div class="container login-panel bg-danger">
	<div class="row">
		<div class="panel panel-default">
		 	<div class="panel-heading">
		 	 	 <h3 class="panel-title">Usuario/Conatraseña incorrecto!</h3>
		 	 </div>
		 	 <div class="panel-body">
					<form class="form-group " action="/dam/MVC/public/login/getUser/" method="POST">
				        <input type="text" id="inputEmail" name="name" class="form-control bg-danger" placeholder="Nombre" required autofocus>
				     	</br>
				        <input type="password" id="inputPassword" name="pass"class="form-control bg-danger" placeholder="Password" required>
				      </br>
				        <button class="btn btn-default"  type="submit">Sign in</button>
				        <a class="btn btn-info" type="button" href="/dam/MVC/public/login/setUserView">Registrar</a>
				    </form>
				
			</div>
		</div>
	</div>
</div>