</br>
</br>
</br>

<div class="container login-panel">
	<div class="row">
		<div class="panel panel-default">
		 	<div class="panel-heading">
		 	 	 <h3 class="panel-title">Hola, esto no tardana nada, pero es para mayor seguridad!</h3>
		 	 </div>
		 	 <div class="panel-body">
				<form class="form-group" action="/dam/MVC/public/login/setUser" method="POST">

				    <input type="text" id="inputEmail" name="name" class="form-control" placeholder="Nombre*" required autofocus>
				     </br>
				    
				    <input type="text" id="inputSurname" name="surname_1" class="form-control" placeholder="Primer Apellido*" required>
				     </br>
				      
				    <input type="text" id="inputSurname" name="surname_2"class="form-control" placeholder="Segundo Apelligo" required>
				    </br>
					  <input type="text" id="inputDNI" name="dni"class="form-control" placeholder="DNI" required>
					     </br>
					  <input type="text" id="inputEmail" name="email"class="form-control" placeholder="Email*" required>
					    </br>
				      <input type="password" id="inputPassword" name="pass"class="form-control" placeholder="Contraseña*" required>
				        </br>
				      <input type="text" id="inputPhone" name="phone"class="form-control" placeholder="Telefono*" required>
				        </br>
				      <input type="text" id="inputAdress" name="adress"class="form-control" placeholder="Direccion*" required>
				        </br> 
				      <input type="text" id="inputZipcode" name="zipcode"class="form-control" placeholder="Codigo Postal*" required>
				        </br>
				      <input type="text" id="inputCity" name="city"class="form-control" placeholder="Ciudad*" required>
				        </br>
				      <input type="text" id="inputCountry" name="country"class="form-control" placeholder="Pais*" required>
				        </br>

				        <button class="btn btn-info" type="submit">Registrar</button> 

				</form>
				
			</div>
		</div>
	</div>
</div>
