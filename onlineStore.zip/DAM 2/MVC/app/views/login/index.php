</br>
</br>
</br>

<div class="container login-panel">
	<div class="row">
		<div class="panel panel-default">
		 	<div class="panel-heading">
		 	 	 <h3 class="panel-title">Hola</h3>
		 	 </div>
		 	 <div class="panel-body">
					<form class="form-group" action="/dam/MVC/public/login/getUser" method="POST">
				        <input type="text" id="inputEmail" name="name" class="form-control" placeholder="Nombre" required autofocus>
				     	</br>
				        <input type="password" id="inputPassword" name="pass"class="form-control" placeholder="Password" required>
				      </br>
				        <button class="btn btn-default"  type="submit">Iniciar</button>
				        <a class="btn btn-info" type="button" href="/dam/MVC/public/login/setUserView">Registrar</a>
				    </form>
				
			</div>
		</div>
	</div>
</div>

 