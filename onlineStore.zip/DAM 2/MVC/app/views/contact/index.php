<div class="container">
	

		</br></br></br></br>
		<div class="jumbotron">
		  <h1>Rodrigo Adelino Candido</h1>
		  <p> Programador Junior, con conocimento en tecnologias Web, .Net y desarrollo movil</p>
		  <a href="http://es.linkedin.com/pub/rodrigo-adelino-candido/90/666/b43">
      
          
          
          
            <img src="https://static.licdn.com/scds/common/u/img/webpromo/btn_viewmy_160x33_es_ES.png?locale=" width="160" height="33" border="0" alt="Ver el perfil de Rodrigo Adelino Candido en LinkedIn">
          
          
          
        
    </a>
		</div>

</div>