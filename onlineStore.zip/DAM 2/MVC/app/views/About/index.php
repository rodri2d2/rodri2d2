<div class="container">
	

		</br></br></br></br>
		<div class="jumbotron">
		  <h1>Tienda Online</h1>
		  <p> Basada en el la metodologia de MVC, Tienda Online se presenta como el Proyecto final del curso de
		  Desarrollo de Aplicaciones Multiplataforma</p>
		  
		</div>

</div>
