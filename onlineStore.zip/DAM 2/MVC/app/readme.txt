La carpeta app es una carpeta contenedora
Su acceso esta controlado por el archivo de 
configuracion del servidor ".htaccess", de forma
que en un caso real, no estaria accesible por un
usuario normal.

Dentro de esta carpeta se encuentan las seguientes
subcarpetas: 
	Controllers
	Models
	Views
	Core
	Helper

Esta caperta contiene los seguintes archivos en su raiz:
	init.php
	.htaccess
	readme.txt


El archivo .htaccess contiene boilerplate code que esta disponible en 
la pagina de apache