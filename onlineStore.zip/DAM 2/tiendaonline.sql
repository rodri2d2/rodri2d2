-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 17-02-2015 a las 07:49:54
-- Versión del servidor: 5.6.21
-- Versión de PHP: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `tiendaonline`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
`idCustomer` int(100) NOT NULL,
  `name` varchar(50) CHARACTER SET armscii8 NOT NULL,
  `surname_1` varchar(50) CHARACTER SET armscii8 NOT NULL,
  `surname_2` varchar(50) CHARACTER SET armscii8 NOT NULL,
  `dni` char(20) CHARACTER SET armscii8 NOT NULL,
  `email` varchar(60) CHARACTER SET armscii8 NOT NULL,
  `password` varchar(64) CHARACTER SET armscii8 NOT NULL,
  `phone` char(20) CHARACTER SET armscii8 NOT NULL,
  `adress` varchar(100) CHARACTER SET armscii8 NOT NULL,
  `zipcode` char(20) CHARACTER SET armscii8 NOT NULL,
  `city` varchar(45) CHARACTER SET armscii8 NOT NULL,
  `country` varchar(45) CHARACTER SET armscii8 NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `customers`
--

INSERT INTO `customers` (`idCustomer`, `name`, `surname_1`, `surname_2`, `dni`, `email`, `password`, `phone`, `adress`, `zipcode`, `city`, `country`) VALUES
(1, 'Rodrigo', 'Adelino', 'Candido', '123456', 'rodrigoipu@hotmail.com', '12345', '00000', 'Direccion de casa de Rodrigo', '30302', 'Irun', 'Basque Country'),
(2, 'Jose', 'Antonio', 'Maria', '123456X', 'joseantonio@tienda,com', '12345', '00000', 'Direccion de casa de Jose', '30302', 'Irun', 'Basque Country'),
(3, 'Elizabeth', 'Romero Garc??a', '1234', 'x12345', 'rodrigoipu@hotmail.com', '1234', '1234', 'Avenida Salis 24 1B', '20304', 'GUIPUZCOA', 'Basque Country'),
(4, 'kkkkkkkkkkkkkk', 'kkkk', 'kkkk', 'kkkkk', 'kkkk', 'kkkk', 'kkkk', 'kkkk', 'kkkk', 'kkkk', 'Basque Countrykkkkk'),
(5, 'q', 'qqqq', 'qqq', 'qqq', 'qqq', 'qqq', 'qqq', 'qqq', 'qq', 'qq', 'qq');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orderdetails`
--

CREATE TABLE IF NOT EXISTS `orderdetails` (
`idOrderDetails` int(100) NOT NULL,
  `idOrder` int(11) NOT NULL,
  `idProduct` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `orderdetails`
--

INSERT INTO `orderdetails` (`idOrderDetails`, `idOrder`, `idProduct`, `quantity`) VALUES
(1, 1, 2, 1),
(2, 1, 2, 1),
(3, 1, 2, 1),
(4, 1, 2, 1),
(5, 3, 4, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
`idOrder` int(100) NOT NULL,
  `idCustomer` int(11) NOT NULL,
  `orderDate` date NOT NULL,
  `state` bit(3) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

--
-- Volcado de datos para la tabla `orders`
--

INSERT INTO `orders` (`idOrder`, `idCustomer`, `orderDate`, `state`) VALUES
(1, 1, '2015-02-10', b'000'),
(2, 1, '2015-02-10', b'000'),
(3, 1, '2015-02-15', b'000');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productimage`
--

CREATE TABLE IF NOT EXISTS `productimage` (
`idImage` int(100) NOT NULL,
  `idProduct` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=armscii8;

--
-- Volcado de datos para la tabla `productimage`
--

INSERT INTO `productimage` (`idImage`, `idProduct`, `image`, `title`, `description`) VALUES
(1, 1, 'senor1.jpg', '1', '1'),
(2, 2, 'hobbit1.jpg', 'El hobbit', 'Embarque en esta aventura'),
(3, 3, 'cuentos1.jpg', 'Cuentos inconclusos', 'Introduccion de Christopher Tolkien'),
(4, 4, 'hurin1.jpg', 'Los hijos de Hurin', 'La ultima novela de tolkien'),
(5, 5, 'silmarilion1.jpg', 'Silmarilion', 'La primera edad'),
(6, 6, 'viento1.jpg', 'El nombre del viento', 'cuenta su historia real!'),
(7, 7, 'temor1.jpg', 'El temor de un homhre sabio', '-'),
(8, 8, 'musica1.jpg', 'La musica del silencio', '-'),
(9, 9, 'inferno.jpg', 'Inferno', '-'),
(10, 10, 'simbolo.jpg', 'El simbolo perdido', '-'),
(11, 11, 'elcodigo.jpg', 'El codigo Da Vinci', '-'),
(12, 12, '7habitos.jpg', 'Los 7 habityos', '-');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE IF NOT EXISTS `products` (
`idProduct` int(100) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `shortDescription` varchar(255) NOT NULL,
  `description` varchar(1000) CHARACTER SET armscii8 NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `longi` double NOT NULL,
  `width` double NOT NULL,
  `heigth` double NOT NULL,
  `stock` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `products`
--

INSERT INTO `products` (`idProduct`, `productName`, `shortDescription`, `description`, `price`, `longi`, `width`, `heigth`, `stock`, `active`) VALUES
(1, 'El senor de los anillos', 'Obra maestra de Tolkien', 'Descubra la Tierra Media', '19', 1, 1, 1, 10, 1),
(2, 'El Hobbit', 'Embarque en esta epica aventura!', 'Smaug parecia profundamente dormido cuando Bilbo espio una vez mas desde la entrada. ?Pero fingia estar dormido!', '15', 1, 1, 1, 10, 1),
(3, 'Cuentos Inconclusos', 'Introduccion de Christopher Tolkien', 'Los Cuentos Inconclusos de Numenor y la Tierra Media es una coleccion de relatos sobre la historia de la Tierra Media desde los Primeros Dias hasta el fin de la Guerra del Anillo.', '22', 1, 1, 1, 10, 1),
(4, 'Los hijos de Hurin', 'Situada en la Primera Edad, cuando elfos...', 'Situada en la Primera Edad, cuando elfos, hombres y enanos llevaban pocos siglos sobre la tierra. La ultima novela de Tolkien narra una historia tragica de amores imposibles...', '32', 1, 1, 1, 9, 1),
(5, 'Silmarilion', 'El Silmarillion cuenta la historia de la Primera Edad', 'El Silmarillion cuenta la historia de la Primera Edad, el antiguo drama del que hablan los personajes de El Senor de los Anillos, y en cuyos acontecimientos algunos tomaron parte, como Elrond y Galadriel...', '21', 1, 1, 1, 10, 1),
(6, 'El nombre del viento', 'Viaje, ame, perdi, confie y me traicionaron.', 'En una posada en tierra de nadie, un hombre se dispone a relatar, por primera vez, la autentica historia de su vida. Una historia que unicamente el conoce y que ha quedado diluida tras los rumores, las conjeturas y los cuentos de taberna', '22', 1, 1, 1, 10, 1),
(7, 'El temor de un hombre sabio', 'Todo hombre sabio teme tres cosas:', 'La tormenta en el mar, la noche sin luna y la ira de un hombre amable.» El hombre habia desaparecido. El mito no. Musico, mendigo, ladron, estudiante, mago, trotamundos, heroe y asesino, Kvothe habia borrado su rastro. ', '18', 1, 1, 1, 10, 1),
(8, 'La musica del silencio', 'La Universidad, el bastion del conocimiento...', 'La Universidad, el bastion del conocimiento, atrae a las mentes mas brillantes, que acuden para aprender los misterios de ciencias como la artificeria y la alquimia.', '12', 1, 1, 1, 10, 1),
(9, 'Inferno', 'Fascinante nuevo thriller, Inferno...', 'En el corazon de Italia, el catedratico de Simbologia de Harvard Robert Langdon se ve arrastrado a un mundo terrorifico centrado en una de las obras maestras de la Literatura mas imperecederas y misteriosas de la Historia: el Infierno de Dante.', '21', 1, 1, 1, 10, 1),
(10, 'El simbolo perdido', 'Existe un secreto tan poderoso que...', 'El experto en simbologia Robert Langdon es convocado inesperadamente por Peter Solomon, mason, filantropo y su antiguo mentor.', '13', 1, 1, 1, 10, 1),
(11, 'El codigo Da Vinci', 'Bestseller Internacional', 'El conservador del museo del Louvre aparece muerto en extra?as circunstancias. Junto a su cadaver ha aparecido un desconcertante mensaje cifrado.', '10', 1, 1, 1, 10, 1),
(12, '7 habitos de la gente mas efectiva', 'Un curso dividido en siete etapas', 'Un curso dividido en siete etapas que el lector deberia adaptar a su personalidad y a su vida cotidiana. El autor se sirve de anecdotas destinadas a hacernos reflexionar sobre cada uno de nuestros actos y sobre el modo de acceder al cambio.', '10', 1, 1, 1, 10, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `customers`
--
ALTER TABLE `customers`
 ADD PRIMARY KEY (`idCustomer`), ADD UNIQUE KEY `DNI` (`dni`);

--
-- Indices de la tabla `orderdetails`
--
ALTER TABLE `orderdetails`
 ADD PRIMARY KEY (`idOrderDetails`);

--
-- Indices de la tabla `orders`
--
ALTER TABLE `orders`
 ADD PRIMARY KEY (`idOrder`);

--
-- Indices de la tabla `productimage`
--
ALTER TABLE `productimage`
 ADD PRIMARY KEY (`idImage`);

--
-- Indices de la tabla `products`
--
ALTER TABLE `products`
 ADD PRIMARY KEY (`idProduct`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `customers`
--
ALTER TABLE `customers`
MODIFY `idCustomer` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `orderdetails`
--
ALTER TABLE `orderdetails`
MODIFY `idOrderDetails` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `orders`
--
ALTER TABLE `orders`
MODIFY `idOrder` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `productimage`
--
ALTER TABLE `productimage`
MODIFY `idImage` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `products`
--
ALTER TABLE `products`
MODIFY `idProduct` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
