#include "main.h"



void Resume(){


	int nFac, codeC, i=0;
	int tamA, tamC, tamO, tamR;
	int codeA;
	char date[10];

	
	FILE *pfA, *pfC, *pfO, *pfR, *pfRepor;
	ARTICLE atc;
	CLIENT clt;
	ORDER odr;
	RESUME res;

	system("cls");

	

			pfO=fopen("orders.dat","rb");
			if(pfO==NULL){

				printf("No hay ningun pedido pendiente");
				getch();
				return;
			}
			//PARA CADA FICHERO SACAR EL TAMA�O PARA UTILISARLO MAS A ADELANTE
			tamO=getSizeOrder(pfO, &odr);


			pfA=fopen("atc.dat", "rb");
			if(pfA==NULL){

				printf("Error!!!");
				printf("\nImposible encontrar achivo...Vuelva a generar lista de ARTICULOS");
				getch();
				return;

			}
			//PARA CADA FICHERO SACAR EL TAMA�O PARA UTILISARLO MAS A ADELANTE
			tamA=getSizeA(pfA, &atc);

			pfC=fopen("clt.dat", "rb");
			if(pfA==NULL){

				printf("Error!!!");
				printf("\nImposible encontrar achivo...Vuelva a generar lista de CLIENTES");
				getch();
				return;

			}

			//PARA CADA FICHERO SACAR EL TAMA�O PARA UTILISARLO MAS A ADELANTE
			tamC=getSizeC(pfC, &clt);

			pfR=fopen("resume.dat", "wb");
			if(pfA==NULL){

				printf("Error!!!");
				printf("\nImposible generar RESUMEN");
				getch();
				return;

			}

			pfRepor=fopen("informe.txt", "w");

			PrintGraphFacturas();

			flushall();
			gotoXY(20, 8);
			printf("Digite numero de Factura: \n");
			gotoXY(46, 8);
			scanf("%d", &nFac);
			system("cls");
			
			
			
			res.baseImpo=0;
				
			
	

			do{
				
				SearchReadO(nFac, pfO, &odr);				
				codeC=odr.nClient;	

				SearchReadC(codeC-1, pfC, &clt);

				
				strcpy(date, getDate());


				fprintf(pfRepor,"\n\t\t\t\t|  FacturacionPlus |\n");			
				fprintf(pfRepor,"________________________________________________________________________________________________________\n");
				
				fprintf(pfRepor,"\n\n");
				fprintf(pfRepor,"%6s: %s\t", "Nombre", clt.name);
				fprintf(pfRepor,"%10s: %s\n", "Domicilio", clt.adress);
				fprintf(pfRepor,"%9s: %s\n", "Municipio", clt.city);
				fprintf(pfRepor,"-------------------------------------------------------------------------------------\n");	

				fprintf(pfRepor,"%10s n: %d \t\t %7s : %10s\n", "FACTURA", nFac, "FECHA", date);
				res.nFactura=nFac;
				fprintf(pfRepor,"--------------------------------------------------------------------------------------\n");
				fprintf(pfRepor,"Articulo \tDen\t \tPVP \tCtd \tImporte \n");
				
				fprintf(pfRepor,"--------------------------------------------------------------------------------------\n");
				
				res.nClient=clt.nClient;
				


				while(nFac<=tamO && codeC==odr.nClient){

					codeA=odr.nArticle;
					SearchReadA(codeA-1, pfA, &atc);
					fprintf(pfRepor, "%d \t%s \t\t%.2f  \t%d  \t%.2f\n", atc.nArticle, atc.denominacion, odr.PVP, odr.Cantidad, (odr.Cantidad*odr.PVP));
					res.baseImpo+=(odr.Cantidad*odr.PVP);
					nFac++;
					SearchReadO(nFac, pfO, &odr);
					
				
				}
				
				
				
				
				res.IVA=18;

				fprintf(pfRepor,"--------------------------------------------------------------------------------------\n");
				fprintf(pfRepor, "\t\t\nBase: %.2f", res.baseImpo);
				fprintf(pfRepor, "\t\t\nIVA: %.2f", res.IVA);
				fprintf(pfRepor, "\t\t\nTOTAL: %.2f\n",((res.IVA*res.baseImpo)/100)+(res.baseImpo));
				fprintf(pfRepor,"\n--------------------------------------------------------------------------------------\n");
				fprintf(pfRepor,"\n\n\n");
					

				

				SearchWriteR(i+1, pfR, &res);


					

			i++;
		
			
			
			}while(nFac<=tamO);

			
			
			fclose(pfA);
			fclose(pfC);
			fclose(pfO);
			fclose(pfR);
			fclose(pfRepor);
			writeResume(date);
			PrintGraphFacturas();
			GraphGenerarFacturas();


			getch();

}

int getSizeResume(FILE *pfR, RESUME *res){


	int tam;

		fseek(pfR, 0, SEEK_END);
		tam=ftell(pfR);
		fseek(pfR, 0, SEEK_SET); 
		tam -= ftell(pfR);
		tam=tam/(sizeof(res));
		return tam;
}

char *getDate(){

	 time_t tiempo = time(0);
        struct tm *tlocal = localtime(&tiempo);
        char output[10];
        strftime(output,10,"%d/%m/%y",tlocal);

		return output;


}


void SearchReadR(int code, FILE *pfR, RESUME *res){


	fseek(pfR,(code)*sizeof(RESUME), SEEK_SET);
	fread(res, sizeof(RESUME), 1, pfR);


}

void SearchWriteR(int code, FILE *pfR, RESUME *res){

	fseek(pfR,(code-1)*sizeof(RESUME), SEEK_SET);
	fwrite(res, sizeof(RESUME), 1, pfR);

}

void writeResume(char *date){



	int tamR, i, tamC, tamO;
	float totales=0;
	
	FILE *pfR, *pfI, *pfC, *pfO;
	RESUME res;
	CLIENT clt;
	ORDER odr;



	pfO=fopen("orders.dat", "rb");
	if(pfO==NULL){
		
		printf("Error! Imposible encontrar Archivo!");

	}
	
	tamO=getSizeOrder(pfO, &odr);

	pfR=fopen("resume.dat", "rb");
	if(pfR==NULL){
		
		printf("Error! Imposible encontrar Archivo!");

	}
	



	pfC=fopen("clt.dat", "rb");
	if(pfR==NULL){
		
		printf("Error! Imposible encontrar Archivo!");

	}





	


		/*****************************/

			pfI=fopen("listado.txt", "w");
		if(pfI==NULL){

			printf("Error al crear informe");
			return;


	
		
		}
		fprintf(pfI, "\t\t\tLISTADO RESUMEN DE FACTURACION DEL %10s\n", date);
		fprintf(pfI,"\n-------------------------------------------------------------------------------\n");
		fprintf(pfI, "N Factura \tCliente\tNIF\t\t\tBase Imp\t IVA");
		fprintf(pfI,"\n-------------------------------------------------------------------------------\n");
	

	for(i=0; i<tamO; i++){

		SearchReadR(i, pfR, &res);
		SearchReadC(res.nClient-1, pfC, &clt);

		fprintf(pfI,"%d\t\t%s\t\t%s\t\t%.2f\t%.2f\n",res.nFactura, clt.name, clt.DNI, res.baseImpo, res.IVA);
		totales+=res.baseImpo;
	}
	fprintf(pfI,"\n--------------------------------------------------------------------------------------\n");
	fprintf(pfI,"\t\t\tTotales: %.2f", totales);

	fclose(pfI);
	fclose(pfC);
	fclose(pfR);


}

void GraphGenerarFacturas(){

	int i;
	
	
	gotoXY(20, 8);
		printf("Generando Facturas.......");

	for(i=0; i<=100; i++){

		Sleep(10);
		gotoXY(48, 8);
		printf("%d", i);

	}

	gotoXY(20, 8);
		printf("Facturas creadas con suceso...!");
	
	

}