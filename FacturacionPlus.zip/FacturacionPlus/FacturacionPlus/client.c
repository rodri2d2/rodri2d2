#include "main.h"



/*Se encarga de pedir y validar si la opcion es correcta o no
tambien carga con opciones graficas*/

int MenuC(){

	int opc;
	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);

	system("title CLIENTES");
	system("cls");
	flushall();
	PrintGraph1();

	do{
		
		 posicion.X=32;
		 posicion.Y=11;
		 SetConsoleCursorPosition(wndH,posicion);
		 printf("1.  ALTA CLIENTES\t");

		posicion.X=32;
		posicion.Y=12;
		SetConsoleCursorPosition(wndH,posicion);
		printf("2.  MODIFICAR\t\t");

		posicion.X=32;
		posicion.Y=13;
		SetConsoleCursorPosition(wndH,posicion);
		printf("3.  COSULTAR\t\t");

		posicion.X=32;
		posicion.Y=14;
		SetConsoleCursorPosition(wndH,posicion);
		printf("4.  MENU PRINCIPAL\t");

		posicion.X=29;
		posicion.Y=18;
		SetConsoleCursorPosition(wndH,posicion);
		printf("Introduce opcion: [ ]");
		posicion.X=48;
		posicion.Y=18;
		SetConsoleCursorPosition(wndH,posicion);
		scanf("%d", &opc);

	
		while(opc<1 || opc>4){
			SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
			posicion.X=29;
			posicion.Y=18;
			SetConsoleCursorPosition(wndH,posicion);
			printf("INCORRECTO..PRESS ENTER");
			getch();
			posicion.X=29;
			posicion.Y=18;
			SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
			SetConsoleCursorPosition(wndH,posicion);
			printf("Introduce opcion: [ ]\t");
			posicion.X=48;
			posicion.Y=18;
			SetConsoleCursorPosition(wndH,posicion);
			flushall();
			scanf("%d", &opc);
		
		}

	}while(opc<1 || opc>4);

	return opc-1;

}


void AddClient(){

	CLIENT clt;
	FILE *pf;
	int tam;
	char resp;
	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);




		pf=fopen("clt.dat","rb+");
		if(pf==NULL){
			pf=fopen("clt.dat", "wb");
		}

		system("cls");
		tam=getSizeC(pf, &clt);
		
		//Para poder ver en numero que sera futuramente el codigo del cliente
		//en la parte superior de la ventana
		posicion.X=28;
		posicion.Y=1;
		SetConsoleCursorPosition(wndH,posicion);
		printf("Numero del Cliente: %d", tam+1);


		//Funcion graficas
		PrintGraph2();	

		fseek(pf, 0, SEEK_END);
		AlterClient(&clt);
		ShowDataC(clt);
		resp=getResp();
		
		//Si la respuesta es positiva guarda los datos, 
		//caso contrario no hace nada
		if(toupper(resp)=='S'){
		
			clt.nClient=tam+1;
			fwrite(&clt, sizeof(clt), 1, pf);
		}
		
		
		
		
		fclose(pf);



}


void AlterClient(CLIENT *clt){

	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);
	flushall();
	
	posicion.X=14;
	posicion.Y=5;
	SetConsoleCursorPosition(wndH,posicion);
	printf("Nombre del cliente:....................");

	posicion.X=14;
	posicion.Y=8;
	SetConsoleCursorPosition(wndH,posicion);
	printf("D.N.I.:................................");

	posicion.X=14;
	posicion.Y=11;
	SetConsoleCursorPosition(wndH,posicion);
	printf("Direccion:.............................");

	posicion.X=14;
	posicion.Y=14;
	SetConsoleCursorPosition(wndH,posicion);
	printf("Municipio:.............................");
	
	
	posicion.X=14;
	posicion.Y=17;
	SetConsoleCursorPosition(wndH,posicion);
	printf("Codigo Postal:.........................");
	


	posicion.X=33;
	posicion.Y=5;
	SetConsoleCursorPosition(wndH,posicion);
	gets(clt->name);
	flushall();
		
	posicion.X=21;
	posicion.Y=8;
	SetConsoleCursorPosition(wndH,posicion);
	gets(clt->DNI);
	flushall();

	posicion.X=24;
	posicion.Y=11;
	SetConsoleCursorPosition(wndH,posicion);
	gets(clt->adress);
	flushall();
	

	posicion.X=24;
	posicion.Y=14;
	SetConsoleCursorPosition(wndH,posicion);
	scanf("%s", &clt->city);
	flushall();
	

	posicion.X=28;
	posicion.Y=17;
	SetConsoleCursorPosition(wndH,posicion);
	gets(clt->postalCode);
	flushall();

}


void LookUpC(){
	FILE *pf;
	CLIENT clt;
	int tam, code;
	int i;
	
		
		pf=fopen("clt.dat", "rb");
		if(pf==NULL){
			printf("error al abrir el fichero");

		}

		tam=getSizeC(pf, &clt);
		PrintGraph3();		
		ShowAll(tam, pf, clt);	
		code=getCode(tam);

		//Sis el valor retornado de code es -1 siplesmente no hace nada
		//retorna al menu
		if(code==-1){
			return;
		}


		SearchReadC(code, pf, &clt);
		ShowDataC(clt);
		getch();
	
		fclose(pf);
}


void ModifyC(){
	FILE *pf;
	CLIENT clt;
	int tam, code;
	int i;
	char resp;
	
		
		pf=fopen("clt.dat", "rb+");
		if(pf==NULL){
			printf("error al abrir el fichero");

		}
		
		tam=getSizeC(pf, &clt);
		ShowAll(tam, pf, clt);
		code=getCode(tam);
		SearchReadC(code, pf, &clt);
		system("cls");
		
		PrintGraph2();

		//Si el codigo es diferente de menos 1 guarda las novas informaciones
		//caso contrario vuelve al menu
		if(code!=-1){
			PrintGraph4();
			AlterClient(&clt);
			resp=getResp();
			SearchWriteC(code, pf, &clt);
		}

		fclose(pf);
		
		
		
		
}


void SearchReadC(int code, FILE *pf, CLIENT *clt){
	
	fseek(pf,(code)*sizeof(CLIENT), SEEK_SET);
	fread(clt, sizeof(CLIENT), 1, pf);


}


void SearchWriteC(int code, FILE *pf, CLIENT *clt){

	fseek(pf,(code)*sizeof(CLIENT), SEEK_SET);
	fwrite(clt, sizeof(CLIENT), 1, pf);
	
}


int getSizeC(FILE *pf, CLIENT clt){

	int tam;

		fseek(pf, 0, SEEK_END);
		tam=ftell(pf);
		fseek(pf, 0, SEEK_SET); 
		tam -= ftell(pf);
		tam=tam/(sizeof(clt));
		return tam;
}


void ShowDataC(CLIENT clt){
				
	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);

	system("cls");
	PrintGraph2();


		posicion.X=14;
		posicion.Y=5;
		SetConsoleCursorPosition(wndH,posicion);
		
		printf("Nombre del cliente: ");
		posicion.X=34;
		posicion.Y=5;
		SetConsoleCursorPosition(wndH,posicion);
		SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
		printf("%s", clt.name);
		
		SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
		posicion.X=20;
		posicion.Y=8;
		SetConsoleCursorPosition(wndH,posicion);
		printf("Direccion: ");
		posicion.X=34;
		posicion.Y=8;
		SetConsoleCursorPosition(wndH,posicion);
		printf("%s", clt.adress);
		
		posicion.X=20;
		posicion.Y=11;
		SetConsoleCursorPosition(wndH,posicion);
		printf("Codigo postal: ");
		posicion.X=34;
		posicion.Y=11;
		SetConsoleCursorPosition(wndH,posicion);
		printf("%s", clt.postalCode);


		posicion.X=20;
		posicion.Y=14;
		SetConsoleCursorPosition(wndH,posicion);
		printf("Municipio: ");
		posicion.X=34;
		posicion.Y=14;
		SetConsoleCursorPosition(wndH,posicion);
		printf("%s", clt.city);


		posicion.X=20;
		posicion.Y=17;
		SetConsoleCursorPosition(wndH,posicion);
		printf("D.N.I.: ");
		posicion.X=34;
		posicion.Y=17;
		SetConsoleCursorPosition(wndH,posicion);
		printf("%s", clt.DNI);
		

	
		
		
	
}


void ShowAll(int tam, FILE *pf, CLIENT clt){
	
	int i, posX=20, posY=5;
	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);
	system("cls");
	system("color 70");

	PrintGraph3();


		for(i=0; i<tam; i++){
			fread(&clt, sizeof(clt), 1, pf);
			posicion.X=posX;
			posicion.Y=posY;
			SetConsoleCursorPosition(wndH,posicion);
			printf("%s-----", clt.name);
			posicion.X=posX+29;
			posicion.Y=posY;
			SetConsoleCursorPosition(wndH,posicion);
			printf("%d", clt.nClient);			
			posY++;
		}
		


}






