﻿#include <stdlib.h>
#include <Windows.h>
#include "main.h"





			main(){
				
				void (*pointer[4])()={MenuClient, MenuArticle, MenuOrder, MenuResume};

				int opc;
				
					opc=Menu();
					while(opc!=4){
					(*pointer[opc])();
					opc=Menu();
					}
					
					


}


int getCode(int tam){

	int code;

	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);
	
	flushall();
	posicion.X=2;
	posicion.Y=20;
	SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
	SetConsoleCursorPosition(wndH,posicion);
	printf("Digite codigo para + informaciones:\t ");
	posicion.X=40;
	posicion.Y=20;
	SetConsoleTextAttribute(wndH,BACKGROUND_GREEN|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
	SetConsoleCursorPosition(wndH,posicion);
	printf("VOLVER(X)");
	posicion.X=35;
	posicion.Y=20;
	SetConsoleCursorPosition(wndH,posicion);
	
	
	scanf("%d", &code);

	
	
	if(code<0){return -1;}


		while(code <0 || code > tam ){
			
			posicion.X=2;
			posicion.Y=20;
			SetConsoleCursorPosition(wndH,posicion);
			SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
			printf("        Codigo incorrecto...!       ");
			getch();
			flushall();
			posicion.X=2;
			posicion.Y=20;
			SetConsoleCursorPosition(wndH,posicion);
			SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
			printf("Digite codigo para + informacion:   ");
			posicion.X=35;
			posicion.Y=20;
			SetConsoleCursorPosition(wndH,posicion);
			scanf("%d", &code);
			
			
		}
	
		
	return code-1;
}

char getResp(){
	
	char resp;
	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);
	
	
		posicion.X=28;
		posicion.Y=1;
		SetConsoleCursorPosition(wndH,posicion);
		SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
		printf("Guardar Cliente (S/N)");
		flushall();
		scanf("%c", &resp);
		
		
		

		return resp;

}

void gotoXY(int x, int y){

	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);


			posicion.X=x;
			posicion.Y=y;
			SetConsoleCursorPosition(wndH,posicion);


}


/* F U N C I O N E S - G R A F I C A S */

void PrintGraph1(){

	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);

	posicion.X=20;
	posicion.Y=8;
	
	system("color 70");
	
		SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
		SetConsoleCursorPosition(wndH,posicion);
	printf(	"╔-------------------------------------------\n");
	posicion.X=20;
	posicion.Y=9;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                          |\n");
	posicion.X=20;
	posicion.Y=10;
	SetConsoleCursorPosition(wndH,posicion);

	printf("|                                          |\n");
		posicion.X=20;
	posicion.Y=11;
	SetConsoleCursorPosition(wndH,posicion);

	printf("|                                          |\n");
		posicion.X=20;
	posicion.Y=12;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                          |\n");
		posicion.X=20;
	posicion.Y=13;
	SetConsoleCursorPosition(wndH,posicion);

	printf("|                                          |\n");
		posicion.X=20;
	posicion.Y=14;
	SetConsoleCursorPosition(wndH,posicion);

	printf("|                                          |\n");
		posicion.X=20;
	posicion.Y=15;
	SetConsoleCursorPosition(wndH,posicion);

	printf("|                                          |\n");
		posicion.X=20;
	posicion.Y=16;
	SetConsoleCursorPosition(wndH,posicion);

	printf("|                                          |\n");
		posicion.X=20;
	posicion.Y=17;
	SetConsoleCursorPosition(wndH,posicion);

	printf("|                                          |\n");
		posicion.X=20;
	posicion.Y=18;
	SetConsoleCursorPosition(wndH,posicion);

	printf("|                                          |\n");
		posicion.X=20;
	posicion.Y=19;
	SetConsoleCursorPosition(wndH,posicion);
	printf("--------------------------------------------\n");
}

void PrintGraph2(){

	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);

	
	posicion.X=12;
	posicion.Y=2;
	system("color 70");
	
		SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
		SetConsoleCursorPosition(wndH,posicion);
	printf(	"---------------------------------------------------\n");
	posicion.X=12;
	posicion.Y=3;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=4;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");
	posicion.X=12;
	posicion.Y=5;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");


	posicion.X=12;
	posicion.Y=6;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");
	
	posicion.X=12;
	posicion.Y=7;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=8;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=9;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");
		
	posicion.X=12;
	posicion.Y=10;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=11;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=12;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=13;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=14;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=15;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=16;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=17;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=18;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=19;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=20;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=21;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=22;
	SetConsoleCursorPosition(wndH,posicion);
	printf(	"---------------------------------------------------\n");
}

void PrintGraph3(){


	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);
	
	system("color 70");

	posicion.X=20;
	posicion.Y=2;
	SetConsoleCursorPosition(wndH,posicion);
	printf("%7s\t\t\t%6s", "NOMBRE", "CODIGO");
	posicion.X=20;
	posicion.Y=3;
	SetConsoleCursorPosition(wndH,posicion);
	printf("----------------------------------");

}

void PrintGraph4(){

	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);
	
	system("color 70");

	posicion.X=20;
	posicion.Y=2;
	SetConsoleCursorPosition(wndH,posicion);
	printf("NUEVOS DATOS");
	




}

void PrintGraph5(){

	
	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);

	
	posicion.X=5;
	posicion.Y=2;
	system("color 70");
	
		SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
		SetConsoleCursorPosition(wndH,posicion);
	printf(	"---------------------------------------------------------------------\n");
	posicion.X=5;
	posicion.Y=3;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=4;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");
	
	posicion.X=5;
	posicion.Y=5;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");


	posicion.X=5;
	posicion.Y=6;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");
	
	posicion.X=5;
	posicion.Y=7;
	SetConsoleCursorPosition(wndH,posicion);
	printf(	"---------------------------------------------------------------------\n");

	posicion.X=5;
	posicion.Y=8;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=9;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");
		
	posicion.X=5;
	posicion.Y=10;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=11;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=12;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=13;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=14;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=15;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=16;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=17;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=18;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=19;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=20;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=21;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                                   |\n");

	posicion.X=5;
	posicion.Y=22;
	SetConsoleCursorPosition(wndH,posicion);
	printf(	"---------------------------------------------------------------------\n");



}

void PrintGraphFacturas(){


	int x, y;
	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);

	
	

	
	posicion.X=12;
	posicion.Y=4;
	system("color 70");
	
		SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
		SetConsoleCursorPosition(wndH,posicion);
	printf(	"---------------------------------------------------\n");
	posicion.X=12;
	posicion.Y=5;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=6;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");
	posicion.X=12;
	posicion.Y=7;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");


	posicion.X=12;
	posicion.Y=8;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");
	
	posicion.X=12;
	posicion.Y=9;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=10;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=11;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");
		
	posicion.X=12;
	posicion.Y=12;
	SetConsoleCursorPosition(wndH,posicion);
	printf("|                                                 |\n");

	posicion.X=12;
	posicion.Y=13;
	SetConsoleCursorPosition(wndH,posicion);
	printf(	"---------------------------------------------------\n");

	
}













