#include <Windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <ctype.h>
#include <time.h>





int Menu();

void MenuClient();

void MenuArticle();

void MenuOrder();

void MenuResume();

char getResp();

void gotoXY(int x, int y);


void PrintGraph1();
void PrintGraph2();
void PrintGraph3();
void PrintGraph4();
void PrintGraph5();
void PrintGraphCabezarioPedidos();
 void PrintGraphFacturas();
 void GraphGenerarFacturas();









/*********    FUNCIONES CONTENIDAS DENTRO DEL CLIENT.C   **********************/


typedef struct{
	
	int nClient;
	char name[25];
	char DNI[10];
	char adress[50];	
	char city[25];
	char postalCode[5];
	
} CLIENT;


int MenuC();

void AddClient();

void AlterClient(CLIENT *);

void ModifyC();

void LookUpC();

void SearchReadC(int , FILE *, CLIENT *);

void SearchWriteC(int , FILE *, CLIENT *);

int getSizeC(FILE *, CLIENT *);

void ShowDataC(CLIENT );

void ShowAll(int, FILE *, CLIENT clt);

int getCode(int );




/****************   FUNCIONES CONTENIDAS DENTRO DEL ARTICLE.C   ********************/

typedef struct{
	
	int nArticle;
	char denominacion[20];
	float costPrice;
	float PVP;
} ARTICLE;


int MenuA();

void AddArticle();

void AlterArticle(ARTICLE *atc);

void ModifyA();

void LookUpA();

void SearchReadA(int, FILE*, ARTICLE *);

void SearchWriteA(int, FILE*, ARTICLE *);

int getSizeA(FILE *, ARTICLE *);

void ShowAllA(int, FILE *, ARTICLE atc);

void ShowDataA(ARTICLE );






/*************** FUNCIONES CONTENIDAS DENTRO DE ORDERS.C    ***************************/

typedef struct{

	int nClient;
	int nArticle;
	float PVP;
	int Cantidad;

}ORDER;


void Order();

int getCodePedidos(int tam);

int getSizeOrder(FILE *, ORDER *);

int getToWrite(int tamO, int codeC, int codeA, FILE *, ORDER *, ARTICLE *, CLIENT *);

char getOPC();

void Save(FILE *, ORDER *, int code);

void getClient(int , FILE *, CLIENT *);

void SearchReadO(int, FILE *, ORDER *);

void SearchWriteOrders(int, FILE *pfO, ORDER *);



/*/*************** FUNCIONES CONTENIDAS DENTRO DE BILLS.C    ***************************/


 typedef struct{

	 int nFactura;
	 int nClient;
	 float baseImpo;
	 float IVA;	

 }RESUME;


 void Resume();
 
 int getSizeResume(FILE *, RESUME *res);

 char *getDate();

 void SearchReadR(int code, FILE *pfR, RESUME *res);

 void SearchWriteR(int code, FILE *pfR, RESUME *res);

 void writeResume(char *);

