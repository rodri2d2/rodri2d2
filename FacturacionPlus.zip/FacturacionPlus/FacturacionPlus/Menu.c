#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <Windows.h>
#include "main.h"




int Menu(){


	int opc;
	 COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);

	system("cls");
	posicion.X=20;
	posicion.Y=8;
	system("title FacturaPlus");
	system("color 70");
	
		PrintGraph1();

		 posicion.X=32;
		 posicion.Y=11;
		 SetConsoleCursorPosition(wndH,posicion);
		 printf("1.  Clientes\t\t\n");

		 posicion.X=32;
		 posicion.Y=12;
		 SetConsoleCursorPosition(wndH,posicion);
		 printf("2.  Articulos\t\t\n");

		 posicion.X=32;
		 posicion.Y=13;
		 SetConsoleCursorPosition(wndH,posicion);
		 printf("3.  Pedidos\t\t\n");

		 posicion.X=32;
		 posicion.Y=14;
		 SetConsoleCursorPosition(wndH,posicion);
		 printf("4.  Facturas\t\t\n");

		 posicion.X=32;
		 posicion.Y=15;
		 SetConsoleCursorPosition(wndH,posicion);
		 printf("5.  Salir\t\t\n");

		 posicion.X=29;
		 posicion.Y=18;
		 SetConsoleCursorPosition(wndH,posicion);
		printf("Introduce opcion: [ ]");
		posicion.X=48;
		 posicion.Y=18;
		 SetConsoleCursorPosition(wndH,posicion);
		 scanf("%d", &opc);
		 	
		 	while(opc<1 || opc>5){
			SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
			posicion.X=29;
			posicion.Y=18;
			SetConsoleCursorPosition(wndH,posicion);
			printf("INCORRECTO..PRESS ENTER");
			getch();
			posicion.X=29;
			posicion.Y=18;
			SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
			SetConsoleCursorPosition(wndH,posicion);
			printf("Introduce opcion: [ ]\t");
			posicion.X=48;
			posicion.Y=18;
			SetConsoleCursorPosition(wndH,posicion);
			flushall();
			scanf("%d", &opc);
		
		}
	
	return opc-1;

	
}

void MenuClient(){	


				
				void (*pointer[3])()={AddClient, ModifyC, LookUpC};

				int opc;
					
					flushall();
					
					opc=MenuC();
					while(opc!=3){					
					(*pointer[opc])();
						opc=MenuC();
					}
			

}

void MenuArticle(){
	
				
				void (*pointer[3])()={AddArticle, ModifyA, LookUpA};

				int opc;
					
					flushall();
					system("cls");
					opc=MenuA();
					while(opc!=3){
					(*pointer[opc])();
					opc=MenuA();
					}
					


}

void MenuOrder(){

	
			void (*pointer[1])()={Order};


			(*pointer[0])();

		


}

void MenuResume(){


			void (*pointer[1])()={Resume};


			(*pointer[0])();

		


}