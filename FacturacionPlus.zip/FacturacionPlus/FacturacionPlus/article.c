#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include "main.h"



int MenuA(){

	int opc;
	
	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);
	system("title ARTICULOS");
	flushall();
	system("cls");
	
	PrintGraph1();
	do{
		
		 posicion.X=32;
		 posicion.Y=11;
		 SetConsoleCursorPosition(wndH,posicion);
		 printf("1.  ALTA ARTICULOS\t");

		posicion.X=32;
		posicion.Y=12;
		SetConsoleCursorPosition(wndH,posicion);
		printf("2.  MODIFICAR\t\t");

		posicion.X=32;
		posicion.Y=13;
		SetConsoleCursorPosition(wndH,posicion);
		printf("3.  COSULTAR\t\t");

		posicion.X=32;
		posicion.Y=14;
		SetConsoleCursorPosition(wndH,posicion);
		printf("4.  MENU PRINCIPAL\t");

		posicion.X=29;
		posicion.Y=18;
		SetConsoleCursorPosition(wndH,posicion);
		printf("Introduce opcion: [ ]");
		posicion.X=48;
		posicion.Y=18;
		SetConsoleCursorPosition(wndH,posicion);
		scanf("%d", &opc);

		while(opc<1 || opc>4){
			SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
			posicion.X=29;
			posicion.Y=18;
			SetConsoleCursorPosition(wndH,posicion);
			printf("INCORRECTO..PRESS ENTER");
			getch();
			posicion.X=29;
			posicion.Y=18;
			SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
			SetConsoleCursorPosition(wndH,posicion);
			printf("Introduce opcion: [ ]\t");
			posicion.X=48;
			posicion.Y=18;
			SetConsoleCursorPosition(wndH,posicion);
			flushall();
			scanf("%d", &opc);		
		}

	}while(opc<1 || opc>4);

	return opc-1;

	

}


void AddArticle(){

		ARTICLE atc;
	FILE *pf;
	int tam;
	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);

		pf=fopen("atc.dat","rb+");
		if(pf==NULL){
			pf=fopen("atc.dat", "wb");
		}

		
		tam=getSizeA(pf, &atc);
		posicion.X=28;
		posicion.Y=1;

		SetConsoleCursorPosition(wndH,posicion);
		printf("Numero del Articulo: %d", tam+1);
		PrintGraph2();

		fseek(pf, 0, SEEK_END);
		AlterArticle(&atc);
		atc.nArticle=tam+1;
		fwrite(&atc, sizeof(atc), 1, pf);
		fclose(pf);



}

void AlterArticle(ARTICLE *atc){

	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);
	flushall();

	posicion.X=14;
	posicion.Y=5;
	SetConsoleCursorPosition(wndH,posicion);
	printf("Denominacion:....................");
		
		

	posicion.X=14;
	posicion.Y=8;
	SetConsoleCursorPosition(wndH,posicion);
	printf("Precion de Coste:_______");

	posicion.X=14;
	posicion.Y=11;
	SetConsoleCursorPosition(wndH,posicion);
	printf("PVP:________");
	

		posicion.X=27;
		posicion.Y=5;
		SetConsoleCursorPosition(wndH,posicion);
		gets(atc->denominacion);

		flushall();
		posicion.X=33;
		posicion.Y=8;
		SetConsoleCursorPosition(wndH,posicion);	
		scanf("%f", &atc->costPrice);
		
		flushall();
		posicion.X=20;
		posicion.Y=11;
		SetConsoleCursorPosition(wndH,posicion);		
		scanf("%f", &atc->PVP);

}

void ModifyA(){
	FILE *pf;
	ARTICLE atc;
	int tam, code;
	int i;
	
		system("cls");
		pf=fopen("atc.dat", "rb+");
		tam=getSizeA(pf, &atc);		
		ShowAllA(tam, pf, atc);
		code=getCode(tam);
		SearchReadA(code, pf, &atc);
		system("cls");

		PrintGraph2();
		
		AlterArticle(&atc);
		SearchWriteA(code, pf, &atc);
		fclose(pf);
		
		
}

void LookUpA(){
	FILE *pf;
	ARTICLE atc;
	int tam, code;
	int i;
	
		system("cls");
		pf=fopen("atc.dat", "rb");
		tam=getSizeA(pf, &atc);
		
		ShowAllA(tam, pf, atc);
		code=getCode(tam);
		if(code==-1){
			return;
		
		}
		SearchReadA(code, pf, &atc);
		ShowDataA(atc);

		
		
		getch();
		fclose(pf);
}


void SearchReadA(int code, FILE *pf, ARTICLE *atc){

		fseek(pf,(code)*sizeof(ARTICLE), SEEK_SET);
		fread(atc, sizeof(ARTICLE), 1, pf);


}


void SearchWriteA(int code, FILE *pf, ARTICLE *atc){
		fseek(pf,(code)*sizeof(ARTICLE), SEEK_SET);
		fwrite(atc, sizeof(ARTICLE), 1, pf);

}


int getSizeA(FILE *pf, ARTICLE atc){

	int tam;

		fseek(pf, 0, SEEK_END);
		tam=ftell(pf);
		fseek(pf, 0, SEEK_SET);
		tam -= ftell(pf);
		tam=tam/(sizeof(atc));
		return tam;
}

void ShowAllA(int tam, FILE *pf, ARTICLE atc){
	
	int i, posX=20, posY=5;
	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);
	system("cls");
	system("color 70");

	PrintGraph3();

		for(i=0; i<tam; i++){
			fread(&atc, sizeof(atc), 1, pf);
			posicion.X=posX;
			posicion.Y=posY;
			SetConsoleCursorPosition(wndH,posicion);
			printf("%s-----", atc.denominacion);
			posicion.X=posX+29;
			posicion.Y=posY;
			SetConsoleCursorPosition(wndH,posicion);
			printf("%d", atc.nArticle);			
			posY++;
		}

}


void ShowDataA(ARTICLE atc){

	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);

	system("cls");
	PrintGraph2();

		posicion.X=14;
		posicion.Y=5;
		SetConsoleCursorPosition(wndH,posicion);
		printf("Denominacion: ");
		posicion.X=34;
		posicion.Y=5;
		SetConsoleCursorPosition(wndH,posicion);
		printf("%s", atc.denominacion);
		
		posicion.X=20;
		posicion.Y=8;
		SetConsoleCursorPosition(wndH,posicion);
		printf("Precio de Coste:..... ");
		posicion.X=42;
		posicion.Y=8;
		SetConsoleCursorPosition(wndH,posicion);
		printf("%.2f", atc.costPrice);
		
		posicion.X=20;
		posicion.Y=11;
		SetConsoleCursorPosition(wndH,posicion);
		printf("PVP:..... ");
		posicion.X=42;
		posicion.Y=11;
		SetConsoleCursorPosition(wndH,posicion);
		printf("%.2f", atc.PVP);

	
}
