#include <stdlib.h>
#include <stdio.h>
#include <conio.h>

typedef struct{
	
	int nArticle;
	char denominacion[20];
	float costPrice;
	float PVP;
} ARTICLE;


int MenuA();

void AddArticle();

void AlterArticle(ARTICLE *atc);

void ModifyA();

void LookUpA();

void SearchReadA(int, FILE*, ARTICLE *);

void SearchWriteA(int, FILE*, ARTICLE *);

int getSizeA(FILE *, ARTICLE *);