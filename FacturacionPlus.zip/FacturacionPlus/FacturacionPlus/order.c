#include "main.h"
#include <stdlib.h>
#include <conio.h>
#include <Windows.h>




void Order(){


	int tamC, tamA, tamO, codeC, codeA, X=1;
	int write, posX, posY, qty, addArticle, i=0;
	char opc;

	FILE *pfO, *pfA, *pfC;
	ORDER odr;
	ARTICLE atc;
	CLIENT clt;

	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);
			
		system("title PEDIDOS");
		

			//APERETURA DE LOS FICHEROS clt.dat(CLIENTES), atc.dat(ARTICULOS)
				pfC=fopen("clt.dat", "rb");
				if(pfC==NULL){
					printf("No hay Registro de Cliente");
					printf("Inserte cliente!");
				}

				pfA=fopen("atc.dat", "rb");
				if(pfA==NULL){
					printf("No hay Registro de Articulos");
					printf("Inserte Articulo!");
				}

				tamC=getSizeC(pfC, &clt);
				tamA=getSizeA(pfA, &atc);


				//APETURA O CREACION DEL FICHERO ORDERS.DAT
				pfO=fopen("orders.dat", "rb+");
				if(pfO==NULL){
					pfO=fopen("orders.dat", "wb");
				}

				tamO=getSizeOrder(pfO, &odr);



				//UNA VEZ TODOS LOS FICHEROS ABIERTOS CORRECTAMENTE

				gotoXY(35, 1);
				printf("PEDIDOS");
				PrintGraph5();
				


				//EMPIEZA EL BUCLE PRINCIPAL

				opc=getOPC();
				PrintGraph5();

				while(opc!='X' && opc=='+'){


					//Pedir y sacar datos del cliente
					gotoXY(6, 4);
					SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
					printf("N Cliente:\n");

					gotoXY(19, 4);
					SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
					codeC=getCodePedidos(tamC);

					SearchReadC(codeC, pfC, &clt);
					gotoXY(19, 4);
					SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
					printf("%s\n", clt.name);

					//POSICIONAMENTO DEL CABECAZARIO

					PrintGraphCabezarioPedidos();

					
					if(tamO!=0){	
						
						for(;i<=tamO && codeC==odr.nClient; i++){
							SearchReadO(i, pfO, &odr);
							

							gotoXY(10+X, 9);
							SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
							printf("%d", odr.nArticle);

							gotoXY(27+X, 9);
							SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
							printf("%s\n", atc.denominacion);

							gotoXY(50+X, 9);
							SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
							printf("%.2f", odr.PVP);

							gotoXY(63+X, 9);
							SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
							printf("%d", odr.Cantidad);

							X++;
				
					
					
				
				}
			}
				

					//PETICION DEL NUMERO DEL ARTICULO
					gotoXY(18,6);
					SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
					flushall();
					codeA=getCodePedidos(tamA);
					SearchReadA(codeA, pfA, &atc);	


							gotoXY(18,6);
							SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);

							gotoXY(10+X, 9);
							SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
							printf("%d", atc.nArticle);

							gotoXY(27+X, 9);
							SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
							printf("%s\n", atc.denominacion);

							gotoXY(50+X, 9);
							SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
							printf("%.2f", atc.PVP);

							gotoXY(63+X, 9);
							SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
							printf("___");

							gotoXY(63+X,9);
							scanf("%d", &qty);

							odr.Cantidad=qty;
							odr.PVP=atc.PVP;
							odr.nArticle=atc.nArticle;							
							odr.nClient=clt.nClient;
							
						

							Save(pfO, &odr, codeC);
							
							
				



					
				flushall();
				opc=getOPC();
				PrintGraph5();
								
				}

					fclose(pfA);
					fclose(pfC);
					fclose(pfO);
	}

int getSizeOrder(FILE *pfO, ORDER odr){


	int tam;

		fseek(pfO, 0, SEEK_END);
		tam=ftell(pfO);
		fseek(pfO, 0, SEEK_SET); 
		tam -= ftell(pfO);
		tam=tam/(sizeof(odr));
		return tam;
}

char getOPC(){

	char opc;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);

	gotoXY(20,10);
	SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
	printf(" < X > VOLVER  < + > ANADIR ATICULO");
	opc=getch();

	return toupper(opc);




}

void Save(FILE *pfO, ORDER *odr, int codeC){

	char opc;
	int i=0;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);

	gotoXY(20,22);
	SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
	printf("Desea guardar los datos? (S/N) ");
	
	opc=getch();
	
	if(toupper(opc)=='S'){
		
		fseek(pfO,(i)*sizeof(ORDER), SEEK_END);
		fwrite(odr, sizeof(ORDER), 1, pfO);
		i++;
	}



}

int getCodePedidos(int tamO){


	int code;

	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);
	
	
	scanf("%d", &code);

	
	
	if(code<0){return -1;}


		while(code <0 || code > tamO ){
			
			gotoXY(20, 1);
			SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
			printf("        Codigo incorrecto...!       ");
			getch();
			flushall();

			gotoXY(20, 1);
			SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
			printf("        Digite codigo      ");

			scanf("%d", &code);
			
			
		}
	
		
	return code-1;


}

void PrintGraphCabezarioPedidos(){

	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);

			posicion.X=6;
			posicion.Y=6;
			SetConsoleCursorPosition(wndH,posicion);			
			printf("N Articulo");


			posicion.X=27;
			posicion.Y=6;
			SetConsoleCursorPosition(wndH,posicion);			
			printf("Denominacion");

			posicion.X=50;
			posicion.Y=6;
			SetConsoleCursorPosition(wndH,posicion);			
			printf("PVP");

			posicion.X=60;
			posicion.Y=6;
			SetConsoleCursorPosition(wndH,posicion);			
			printf("Cantidad");
}

void SearchReadO(int nFac, FILE *pfO, ORDER *odr){

	fseek(pfO,(nFac-1)*sizeof(ORDER), SEEK_SET);
	fread(odr, sizeof(ORDER), 1, pfO);

}