/*#include "main.h"
#include <stdlib.h>
#include <conio.h>




void Order(){

			int tamC, tamA, tamO, codeC, codeA;
			int write, posX, posY, qty, addArticle;
			char resp;


			FILE *pfO, *pfA, *pfC;
			ORDER odr;
			ARTICLE atc;
			CLIENT clt;

			COORD posicion;
			HANDLE wndH;
			wndH=GetStdHandle(STD_OUTPUT_HANDLE);
			system("title PEDIDOS");
			
		do{
			system("cls");
			posicion.X=35;
			posicion.Y=1;
			SetConsoleCursorPosition(wndH,posicion);			
			printf("PEDIDOS");
			PrintGraph5();

		
			
				
				//APERETURA DE LOS FICHEROS clt.dat(CLIENTES), atc.dat(ARTICULOS)
				pfC=fopen("clt.dat", "rb");
				if(pfC==NULL){
					printf("No hay Registro de Cliente");
					printf("Inserte cliente!");
				}

				pfA=fopen("atc.dat", "rb");
				if(pfA==NULL){
					printf("No hay Registro de Articulos");
					printf("Inserte Articulo!");
				}

				tamC=getSizeC(pfC, &clt);
				tamA=getSizeA(pfA, &atc);
				
				//APERTURA DEL FICHERO order.dat(PEDIDOS)
				
				pfO=fopen("orders.dat", "rb+");
				if(pfO==NULL){
					pfO=fopen("orders.dat", "wb");
				}

				tamO=getSizeOrder(pfO, &odr);

				

				//Posicionamento y codigo del cliente	
				posicion.X=6;
				posicion.Y=4;
				SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
				SetConsoleCursorPosition(wndH,posicion);			
				printf("N Cliente:\n");
		
				
				posicion.X=19;
				posicion.Y=4;
				SetConsoleCursorPosition(wndH,posicion);
				SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
				codeC=getCodePedidos(tamC);

				SearchReadC(codeC, pfC, &clt);
				posicion.X=19;
				posicion.Y=4;
				SetConsoleCursorPosition(wndH,posicion);
				SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
				printf("%s\n", clt.name);

				//posicionamento cabezario
				
				PrintGraphCabezarioPedidos();

				//Posicionamento  del articulo
			do{
				posicion.X=18;
				posicion.Y=6;
				SetConsoleCursorPosition(wndH,posicion);
				SetConsoleTextAttribute(wndH,BACKGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
				flushall();
				codeA=getCodePedidos(tamA);
				SearchReadA(codeA, pfA, &atc);

				
				
					write=getToWrite(tamO, codeC, codeA, pfO, &odr, &atc, &clt);
			
				
				if(write>0){
						posicion.Y=posicion.Y+1;
					
							posicion.X=10;
							posicion.Y=9;
							SetConsoleCursorPosition(wndH,posicion);
							SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
							printf("%d", atc.nArticle);

							posicion.X=27;
							posicion.Y=9;
							SetConsoleCursorPosition(wndH,posicion);
							SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
							printf("%s\n", atc.denominacion);

							posicion.X=50;
							posicion.Y=9;
							SetConsoleCursorPosition(wndH,posicion);
							SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
							printf("%.2f", atc.PVP);

							posicion.X=63;
							posicion.Y=9;
							SetConsoleCursorPosition(wndH,posicion);
							SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
							printf("__");
							posicion.X=63;
							posicion.Y=9;
							SetConsoleCursorPosition(wndH,posicion);
							scanf("%d", &qty);
							odr.Cantidad+=qty;
								
						





				}else{


					posicion.Y=posicion.Y+1;

				posicion.X=10;
				posicion.Y=9;
				SetConsoleCursorPosition(wndH,posicion);
				SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
				printf("%d", atc.nArticle);

				posicion.X=27;
				posicion.Y=9;
				SetConsoleCursorPosition(wndH,posicion);
				SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
				printf("%s\n", atc.denominacion);

				posicion.X=50;
				posicion.Y=9;
				SetConsoleCursorPosition(wndH,posicion);
				SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
				printf("%.2f", atc.PVP);

			
				posicion.X=63;
				posicion.Y=9;
				SetConsoleCursorPosition(wndH,posicion);
				SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
				printf("__");
				posicion.X=63;
				posicion.Y=9;
				SetConsoleCursorPosition(wndH,posicion);
				scanf("%d", &odr.Cantidad);

			
				
				}
			

				codeA=getCodePedidos(tamA);
				SearchReadA(codeA, pfA, &atc);
				

				
				} while(codeA<0);

		
				resp=getResp();
				if(toupper(resp)=='S'){
					odr.nClient=clt.nClient;
					odr.nArticle=atc.nArticle;
					fwrite(&odr, sizeof(odr), 1, pfO);
				}

				flushall();

				resp=getRespOrder();

			}while(toupper(resp)!='N');

	fclose(pfA);
	fclose(pfC);
	fclose(pfO);
}


int getSizeOrder(FILE *pfO, ORDER odr){


	int tam;

		fseek(pfO, 0, SEEK_END);
		tam=ftell(pfO);
		fseek(pfO, 0, SEEK_SET); 
		tam -= ftell(pfO);
		tam=tam/(sizeof(odr));
		return tam;

}

int getToWrite(int tamO, int codeC, int codeA, FILE *pfO, ORDER odr, ARTICLE atc, CLIENT clt){

	int i, qty;
	
	flushall();
		for(i=0; i<tamO;i++){

			
			fread(&odr, sizeof(ORDER), 1, pfO);

			if(odr.nClient==codeC && clt.nClient==codeC && odr.nArticle == codeA && atc.nArticle==codeA){
				return 0;
			} else return 1;
		}

	

}

void SearchReadOrders(int code, FILE *pfO, ORDER *odr){
		
	fseek(pfO,(code)*sizeof(ORDER), SEEK_SET);
	fread(odr, sizeof(ORDER), 1, pfO);

}

int getCodePedidos(int tamO){


	int code;

	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);
	
	
	scanf("%d", &code);

	
	
	if(code<0){return -1;}


		while(code <0 || code > tamO ){
			
			posicion.X=20;
			posicion.Y=1;
			SetConsoleCursorPosition(wndH,posicion);	
			SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
			printf("        Codigo incorrecto...!       ");
			getch();
			flushall();
			posicion.X=20;
			posicion.Y=1;
			SetConsoleCursorPosition(wndH,posicion);	
			SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
			printf("        Digite codigo      ");

			scanf("%d", &code);
			
			
		}
	
		
	return code-1;


}


char getRespOrder(){
	
	char resp;
	COORD posicion;
	HANDLE wndH;
	wndH=GetStdHandle(STD_OUTPUT_HANDLE);
	
	
		posicion.X=28;
		posicion.Y=1;
		SetConsoleCursorPosition(wndH,posicion);
		SetConsoleTextAttribute(wndH,BACKGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
		printf("Desea insertar otro pedido? (S/N)");
		flushall();
		scanf("%c", &resp);
		
		
		

		return resp;

}
*/




